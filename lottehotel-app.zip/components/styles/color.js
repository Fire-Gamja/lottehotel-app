export default{
    primary : "#978773",
    gray : "#efefef",
    text:{
        black : "#111",
        white : "#fff",
        gray : "#949494"
    }
};